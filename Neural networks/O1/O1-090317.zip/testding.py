import numpy as np
import matplotlib.pyplot as plt

rand=np.random.rand;

a=rand(5);
b=a>0.5;
print(a);
print(b);
print(2*b);
import numpy as np;
import matplotlib.pyplot as plt;
import sklearn.metrics as skm;

#import sklearn.metrics.pairwise.pairwise.distances as skd;

NUM_TEST=1000;
NUM_TRAIN=1707;

test_in=np.genfromtxt("test_in.csv", delimiter=',');
test_out=np.genfromtxt("test_out.csv", delimiter=',');
train_in=np.genfromtxt("train_in.csv", delimiter=',');
train_out=np.genfromtxt("train_out.csv", delimiter=',');

def euclidian_dist(x, y):
	return np.sqrt(sum((x-y)**2));

def get_clouds(data_in, data_out):
	clouds=[[]]*10;
	for i in range(0, NUM_TRAIN):
		digit=data_out[i];
		digit_index=np.int(digit);
		if clouds[digit_index]==[]:
			clouds[digit_index]=data_in[i];
		else:
			clouds[digit_index]=np.vstack([clouds[digit_index], data_in[i]]);
	return clouds;
	
def get_centres(clouds):
	centres=np.empty([10, 256]);	
	for i in range(0, 10):
		centres[i]=np.mean(clouds[i], axis=0);	
	return centres;
	
def classify_1(data_in, centres, metriek):
	distances = skm.pairwise.pairwise_distances(data_in, centres, metric = metriek);
	classes = distances.argmin(axis = 1);
	return classes;


train_clouds=get_clouds(train_in, train_out); 
train_centres=get_centres(train_clouds);

#avg_whitespace = [[]]*10;

#for i in range(0,10):
#	avg_whitespace[i] = (train_clouds[i]*(train_clouds[i] == -1)).sum(axis = 1).sum()/train_clouds[i].shape[0]
#print(avg_whitespace)

bins = np.linspace(-230,-70,30)
def get_histograms(class1, class2):
	wspace1 = (train_clouds[class1]*(train_clouds[class1] == -1)).sum(axis = 1);
	wspace2 = (train_clouds[class2]*(train_clouds[class2] == -1)).sum(axis = 1);
	plt.hist(wspace1, bins , facecolor = 'green', alpha = 0.5, label = 'class1');
	
	plt.hist(wspace2, bins ,alpha = 0.5, label = 'class2');
	plt.xlabel('amount of whitespace');
	plt.legend(loc='upper right');
	


#get_histograms(2,3)
#plt.show()
#image = np.empty([16,16])

#for i in range(0,16):
#	image[i] = train_in[1,(16*i):(16*(i+1))]


#plt.imshow(image)
#plt.show()

class1=0; class2=1;
wspace1 = (train_clouds[class1]*(train_clouds[class1] == -1)).sum(axis = 1);
wspace2 = (train_clouds[class2]*(train_clouds[class2] == -1)).sum(axis = 1)	;
#W=np.append(wspace1, wspace2);

values1 = np.histogram(wspace1, bins);
values2 = np.histogram(wspace2, bins);
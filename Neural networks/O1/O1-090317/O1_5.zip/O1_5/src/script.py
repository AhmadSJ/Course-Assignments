import mnist_loader;
import network;
import numpy as np;

#training_data, validation_data, test_data = mnist_loader.load_data_wrapper();

test_in=np.genfromtxt("test_in.csv", delimiter=',');
test_out=np.genfromtxt("test_out.csv", delimiter=',');
train_in=np.genfromtxt("train_in.csv", delimiter=',');
train_out=np.genfromtxt("train_out.csv", delimiter=',');

training_data=[[]]*len(train_out);
test_data=[[]]*len(test_out);

for i in range(0, len(train_out)):
	training_data[i]=[train_in[i], train_out[i]];
for i in range(0, len(test_out)):
	test_data[i]=[test_in[i], test_out[i]];

#for (x, y) in training_data: print(x, y);

#print(training_data);
net=network.Network([256, 30, 10]);

net.SGD(training_data, 30, 10, 3.0);#, test_data=test_data);
import numpy as np
import matplotlib.pyplot as plt

rand=np.random.rand;

a=[1, 2, 3, 4, 5, 6];
print(a[0:3])
print(a[3:6]);